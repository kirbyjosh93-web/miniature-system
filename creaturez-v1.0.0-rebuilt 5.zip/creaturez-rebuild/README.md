# Creaturez v1.0.0

A retro-inspired barcode creature collecting game built with Expo and React Native.

## Included
- Barcode scanning (EAN-13, EAN-8, UPC-A, UPC-E) and manual barcode entry
- Deterministic local creature discovery with 12 original species and rarity tiers
- Collection, training, leveling, and evolution
- Five unlockable regions and simulated arena/boss encounters
- Field Supply Depot with consumables and scanner finishes
- Player profile, daily scan challenge, achievements, and first-run tutorial
- Local save persistence with JSON export/import

## Run locally
1. Install Node.js LTS.
2. Extract this project.
3. In the project folder run `npm install`.
4. Run `npx expo start`.
5. Open the QR code with Expo Go on your iPhone or Android device.

Camera access is required for barcode scanning. Manual barcode entry is also available.

## Notes
- All barcode-to-creature mapping is generated locally. The app does not identify retail products or upload scan data.
- Battles and boss encounters in this starter release are locally simulated gameplay.
- This is source code, not a signed IPA/APK. Native builds, store submission, and physical-device QA have not been completed.
